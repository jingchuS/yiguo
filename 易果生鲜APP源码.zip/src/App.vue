<template>
  <div id="app">
    <Home></Home>
  </div>
</template>

<script> 
import Home from '@/components/Home.vue';
import "@/assets/styles/reset.css";
export default {
  name: 'app',
  components: {
    Home
  }
}
</script>

<style>

</style>
