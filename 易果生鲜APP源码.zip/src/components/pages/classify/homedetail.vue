<template>
    <div class="homedetail">
        <div class="imG">
            <img src="//img14.yiguoimg.com/d/items/2019/190417/9288737794369169_1125x1010.jpg?w=1125&h=1010" alt="">
        </div>
        <!-- 11 -->
        <div class="imG2">
            <img src="//img12.yiguoimg.com/e/items/2017/170606/9288708708115142_500.jpg" alt="">
            <div class="imG2txt">
                <h2 class="h2txt">一手难握的鲜嫩，让舌尖触碰深海</h2>
                <h3 class="h3txt">越南黑虎虾</h3>
                <div class="pricE">
                    <span class="procEspan1">¥</span>
                    <span class="procEspan2">55</span>
                    <span class="procEspan3">.90/</span>
                    <span class="procEspan4">400g</span>
                    <span class="procEspan5">加入购物车</span>
                </div>
            </div>
        </div>
        <!-- 22 -->
        <div class="imG2">
            <img src="//img10.yiguoimg.com/d/items/2018/181101/9288733414892897_500.jpg" alt="">
            <div class="imG2txt">
                <h2 class="h2txt">去皮去骨高营养，轻轻一煎满屋香</h2>
                <h3 class="h3txt">美威欧式原味三文鱼排</h3>
                <div class="pricE">
                    <span class="procEspan1">¥</span>
                    <span class="procEspan2">62</span>
                    <span class="procEspan3">.90/</span>
                    <span class="procEspan4">250g</span>
                    <span class="procEspan5">加入购物车</span>
                </div>
            </div>
        </div>
        <!-- 33 -->
        <div class="imG2">
            <img src="//img10.yiguoimg.com/d/items/2018/180614/9288724545086670_500.jpg" alt="">
            <div class="imG2txt">
                <h2 class="h2txt">个大饱满肉质紧，鲜嫩低脂高蛋白</h2>
                <h3 class="h3txt">原膳越南草虾仁</h3>
                <div class="pricE">
                    <span class="procEspan1">¥</span>
                    <span class="procEspan2">38</span>
                    <span class="procEspan3">.00/</span>
                    <span class="procEspan4">200g</span>
                    <span class="procEspan5">加入购物车</span>
                </div>
            </div>
        </div>
        <!-- 44 -->
        <div class="imG2">
            <img src="//img14.yiguoimg.com/d/items/2017/171109/9288714859193193_500.jpg" alt="">
            <div class="imG2txt">
                <h2 class="h2txt">无刺无骨，即刻享“瘦”</h2>
                <h3 class="h3txt">越南冷冻巴沙鱼片</h3>
                <div class="pricE">
                    <span class="procEspan1">¥</span>
                    <span class="procEspan2">38</span>
                    <span class="procEspan3">.00/</span>
                    <span class="procEspan4">200g</span>
                    <span class="procEspan5">加入购物车</span>
                </div>
            </div>
        </div>
        <!-- 55 -->
        <div class="imG2">
            <img src="//img09.yiguoimg.com/d/items/2017/171204/9288716047229828_500.jpg" alt="">
            <div class="imG2txt">
                <h2 class="h2txt">色泽青翠肉饱满，营养丰富大口吃</h2>
                <h3 class="h3txt">半壳冷冻青口贝</h3>
                <div class="pricE">
                    <span class="procEspan1">¥</span>
                    <span class="procEspan2">59</span>
                    <span class="procEspan3">.00/</span>
                    <span class="procEspan4">500g</span>
                    <span class="procEspan5">加入购物车</span>
                </div>
            </div>
        </div>
        <!-- 66 -->
        <div class="img66">
            <img src="//img13.yiguoimg.com/d/items/2018/180608/9288724264559816_1125x260.jpg?w=1125&h=260" alt="">
        </div>
    </div>
</template>

<script>
export default {
    
}
</script>

<style>
 .homedetail {
     width: 100%;
     height: 617px;
     overflow-y: auto;
 }   
 .imG {
     width: 375px;
     height: 336px;
 }
 .imG img {
     width: 375px;
     height: 336px;
 } 
 .imG2 {
     width: 375px;
     height: 375px;
     background: rgb(193, 225, 241);
     position: relative;
 }
 .imG2 img {
     width: 349px;
     height: 349px;
     margin-left: 12px;
     margin-top: 10px;
 }
 .imG2txt {
     position: absolute;
     background: white;
     width: 349px;
     height: 102px;
     top: 257px;
     left: 12px;
 }
 .h2txt {
     line-height: 20px;
     margin-left: 20px;
     margin-top: 5px;
 }
 .h3txt {
     line-height: 20px;
     margin-left: 20px;
     margin-top: 5px;
 }
 .pricE {
     color: rgb(28, 67, 120);
 }
 .procEspan1 {
     font-size: 12px;
     margin-left: 20px;
 }
 .procEspan2 {
     font-size: 23px;
 }
 .procEspan3 {
     font-size: 12px;
 }
 .procEspan4 {
     font-size: 14px;
 }
 .procEspan5 {
     display: inline-block;
     width: 105px;
     height: 30px;
     background: rgb(28, 67, 120);
     color: white;
     text-align: center;
     line-height: 30px;
     margin-left: 100px;
 }
 .img66 img {
     width: 375px;
     height: 88px;
 }
</style>