// module.exports = {
//     // ...
//     dev: {
//       proxyTable: {
//         // proxy all requests starting with /api to jsonplaceholder
//         '/list': {
//           target: 'http://m.doumi.com',
//         //   secure: false,
//           changeOrigin: true,
//           pathRewrite: {
//             '^/list': ''
//           }
//         }
//       }
//     }
//   }